package it.leggio.spartiti;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String BASE = "https://appassets.androidplatform.net";
    private static final int PICK = 1, PICKDOC = 2, SAVE = 3, OPENTXT = 4;
    private static final int B64 = Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING;
    private FrameLayout root;
    private WebView web, browser;
    private LinearLayout browserBox;
    private TextView browserTitle;
    private ValueCallback<Uri[]> fileCb;
    private String pendingText;
    private boolean ready = false;
    private final List<String> pending = new ArrayList<>();
    private final ExecutorService ex = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        root = new FrameLayout(this);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Bridge(), "Leggio");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String p = u.getPath();
                if ("appassets.androidplatform.net".equals(u.getHost()) && p != null && p.startsWith("/f/"))
                    return serve(p.substring(3));
                return loader.shouldInterceptRequest(u);
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith(BASE + "/")) return false;
                if (u.startsWith("http")) openBrowser(u);
                return true;
            }
            @Override
            public void onPageFinished(WebView v, String url) {
                ready = true;
                for (String js : pending) web.evaluateJavascript(js, null);
                pending.clear();
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(Intent.createChooser(i, "Scegli i file"), PICK);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        web.loadUrl(BASE + "/assets/index.html");
        handleIntent(getIntent());
    }

    /* ---------- file per riferimento ---------- */

    private String urlFor(Uri u) {
        return BASE + "/f/" + Base64.encodeToString(u.toString().getBytes(StandardCharsets.UTF_8), B64);
    }

    private Uri uriOf(String key) {
        return Uri.parse(new String(Base64.decode(key, B64), StandardCharsets.UTF_8));
    }

    private String mimeOf(Uri u, String name) {
        String m = null;
        try { m = getContentResolver().getType(u); } catch (Exception ignored) { }
        if (m == null) {
            String ext = MimeTypeMap.getFileExtensionFromUrl(name == null ? u.toString() : name.replace(' ', '_'));
            if (ext != null) m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase());
        }
        return m == null ? "application/octet-stream" : m;
    }

    private WebResourceResponse serve(String key) {
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        h.put("Cache-Control", "no-store");
        try {
            Uri src = uriOf(key);
            InputStream in = getContentResolver().openInputStream(src);
            if (in == null) throw new IOException();
            return new WebResourceResponse(mimeOf(src, src.getLastPathSegment()), null, 200, "OK", h, in);
        } catch (Exception e) {
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", h, new ByteArrayInputStream(new byte[0]));
        }
    }

    private String nameOf(Uri u) {
        if ("file".equals(u.getScheme())) return u.getLastPathSegment();
        try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int k = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (k >= 0) return c.getString(k);
            }
        } catch (Exception ignored) { }
        return "Spartito";
    }

    private JSONObject entry(Uri u, String name, String mime) throws Exception {
        JSONObject o = new JSONObject();
        o.put("url", urlFor(u));
        o.put("name", name);
        o.put("mime", mime);
        return o;
    }

    private void js(final String code) {
        ui.post(() -> {
            if (ready) web.evaluateJavascript(code, null);
            else pending.add(code);
        });
    }

    /* Copia un file nella memoria dell'app (per i download e i file condivisi) */
    private void saveCopy(InputStream in, String name, String mime) throws Exception {
        File dir = new File(getFilesDir(), "scaricati");
        if (!dir.exists()) dir.mkdirs();
        String safe = name.replaceAll("[^A-Za-z0-9._ \\-àèéìòùÀÈÉÌÒÙ]", "_");
        File f = new File(dir, System.currentTimeMillis() + "_" + safe);
        try (OutputStream out = new FileOutputStream(f)) {
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
        JSONArray a = new JSONArray();
        a.put(entry(Uri.fromFile(f), name, mime));
        js("leggioAdd(" + a + ")");
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        handleIntent(i);
    }

    private void handleIntent(Intent i) {
        if (i == null) return;
        Uri u = null;
        if (Intent.ACTION_VIEW.equals(i.getAction())) u = i.getData();
        else if (Intent.ACTION_SEND.equals(i.getAction())) u = i.getParcelableExtra(Intent.EXTRA_STREAM);
        if (u == null) return;
        final Uri uri = u;
        final String name = nameOf(uri);
        final String mime = mimeOf(uri, name);
        ex.execute(() -> {
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                saveCopy(in, name, mime);
            } catch (Exception e) {
                toast("Impossibile aprire il file");
            }
        });
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        List<Uri> uris = new ArrayList<>();
        if (res == RESULT_OK && data != null) {
            if (data.getClipData() != null)
                for (int k = 0; k < data.getClipData().getItemCount(); k++) uris.add(data.getClipData().getItemAt(k).getUri());
            else if (data.getData() != null) uris.add(data.getData());
        }
        if (req == PICK) {
            if (fileCb != null) fileCb.onReceiveValue(uris.isEmpty() ? null : uris.toArray(new Uri[0]));
            fileCb = null;
        } else if (req == PICKDOC && !uris.isEmpty()) {
            try {
                JSONArray a = new JSONArray();
                for (Uri u : uris) {
                    try {
                        getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (Exception ignored) { }
                    String n = nameOf(u);
                    a.put(entry(u, n, mimeOf(u, n)));
                }
                js("leggioPicked(" + a + ")");
            } catch (Exception e) {
                toast("Errore nella scelta dei file");
            }
        } else if (req == SAVE && !uris.isEmpty() && pendingText != null) {
            try (OutputStream out = getContentResolver().openOutputStream(uris.get(0), "wt")) {
                out.write(pendingText.getBytes(StandardCharsets.UTF_8));
                toast("Raccolta esportata");
            } catch (Exception e) {
                toast("Esportazione non riuscita");
            }
            pendingText = null;
        } else if (req == OPENTXT && !uris.isEmpty()) {
            try (InputStream in = getContentResolver().openInputStream(uris.get(0))) {
                js("leggioLoadList(" + JSONObject.quote(new String(readAll(in), StandardCharsets.UTF_8)) + ")");
            } catch (Exception e) {
                toast("Impossibile leggere il file");
            }
        }
    }

    /* ---------- browser interno per scaricare ---------- */

    private void openBrowser(String url) {
        if (browserBox == null) {
            browserBox = new LinearLayout(this);
            browserBox.setOrientation(LinearLayout.VERTICAL);
            browserBox.setBackgroundColor(Color.WHITE);
            LinearLayout bar = new LinearLayout(this);
            bar.setGravity(Gravity.CENTER_VERTICAL);
            bar.setBackgroundColor(Color.rgb(242, 242, 247));
            bar.setPadding(12, 8, 12, 8);
            Button back = new Button(this);
            back.setText("‹ Indietro");
            back.setOnClickListener(v -> { if (browser.canGoBack()) browser.goBack(); });
            Button close = new Button(this);
            close.setText("Fine");
            close.setOnClickListener(v -> browserBox.setVisibility(View.GONE));
            browserTitle = new TextView(this);
            browserTitle.setSingleLine(true);
            browserTitle.setTextSize(15);
            browserTitle.setTextColor(Color.BLACK);
            browserTitle.setPadding(16, 0, 16, 0);
            bar.addView(back);
            bar.addView(browserTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            bar.addView(close);
            TextView hint = new TextView(this);
            hint.setText("Scarica un PDF: verrà importato da solo nella cartella scelta");
            hint.setTextSize(12);
            hint.setTextColor(Color.rgb(110, 110, 115));
            hint.setPadding(24, 4, 24, 8);
            hint.setBackgroundColor(Color.rgb(242, 242, 247));
            browser = new WebView(this);
            final WebSettings s = browser.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setBuiltInZoomControls(true);
            s.setDisplayZoomControls(false);
            s.setUseWideViewPort(true);
            s.setLoadWithOverviewMode(true);
            CookieManager.getInstance().setAcceptThirdPartyCookies(browser, true);
            browser.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                    String u = r.getUrl().toString();
                    if (!u.startsWith("http")) return true;
                    if (u.toLowerCase().matches(".*\\.pdf([?#].*)?$")) {
                        fetch(u, s.getUserAgentString(), null, null);
                        return true;
                    }
                    return false;
                }
                @Override
                public void onPageFinished(WebView v, String u) {
                    browserTitle.setText(v.getTitle());
                }
            });
            browser.setDownloadListener((u, ua, cd, mime, len) -> fetch(u, ua, cd, mime));
            browserBox.addView(bar, new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
            browserBox.addView(hint, new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
            browserBox.addView(browser, new LinearLayout.LayoutParams(-1, 0, 1));
            root.addView(browserBox, new FrameLayout.LayoutParams(-1, -1));
        }
        browserBox.setVisibility(View.VISIBLE);
        browser.loadUrl(url);
    }

    private void fetch(final String url, final String ua, final String cd, final String mime0) {
        if (url.startsWith("blob:") || url.startsWith("data:")) { toast("Questo download non è supportato"); return; }
        toast("Download in corso…");
        final String agent = ua != null ? ua : WebSettings.getDefaultUserAgent(this);
        ex.execute(() -> {
            HttpURLConnection c = null;
            try {
                String u = url;
                for (int k = 0; k < 8; k++) {
                    c = (HttpURLConnection) new URL(u).openConnection();
                    c.setInstanceFollowRedirects(false);
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(90000);
                    c.setRequestProperty("User-Agent", agent);
                    String ck = CookieManager.getInstance().getCookie(u);
                    if (ck != null) c.setRequestProperty("Cookie", ck);
                    int code = c.getResponseCode();
                    if (code >= 300 && code < 400 && c.getHeaderField("Location") != null) {
                        u = new URL(new URL(u), c.getHeaderField("Location")).toString();
                        c.disconnect();
                        continue;
                    }
                    break;
                }
                if (c.getResponseCode() >= 400) throw new IOException("HTTP " + c.getResponseCode());
                String mime = c.getContentType() != null ? c.getContentType() : (mime0 != null ? mime0 : "");
                if (mime.contains("text/html")) {
                    toast("Il link non porta a un PDF: aprilo e scarica il file");
                    ui.post(() -> openBrowser(url));
                    return;
                }
                String disp = c.getHeaderField("Content-Disposition") != null ? c.getHeaderField("Content-Disposition") : cd;
                String name = URLUtil.guessFileName(u, disp, mime);
                try (InputStream in = c.getInputStream()) { saveCopy(in, name, mime); }
                toast("Spartito importato: " + name);
            } catch (Exception e) {
                toast("Download non riuscito");
            } finally {
                if (c != null) c.disconnect();
            }
        });
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        return out.toByteArray();
    }

    private void toast(final String t) {
        ui.post(() -> Toast.makeText(this, t, Toast.LENGTH_SHORT).show());
    }

    @Override
    public void onBackPressed() {
        if (browserBox != null && browserBox.getVisibility() == View.VISIBLE) {
            if (browser.canGoBack()) browser.goBack();
            else browserBox.setVisibility(View.GONE);
            return;
        }
        web.evaluateJavascript("window.leggioBack?leggioBack():false", v -> {
            if (!"true".equals(v)) finish();
        });
    }

    private class Bridge {
        @JavascriptInterface
        public void download(String url) { ui.post(() -> fetch(url, null, null, null)); }

        @JavascriptInterface
        public void browse(String url) { ui.post(() -> openBrowser(url)); }

        @JavascriptInterface
        public void pick() {
            ui.post(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/pdf", "image/*"});
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                try { startActivityForResult(i, PICKDOC); } catch (Exception e) { toast("Impossibile aprire la scelta dei file"); }
            });
        }

        @JavascriptInterface
        public void saveText(String name, String text) {
            ui.post(() -> {
                pendingText = text;
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE, name);
                try { startActivityForResult(i, SAVE); } catch (Exception e) { toast("Impossibile salvare il file"); }
            });
        }

        @JavascriptInterface
        public void openText() {
            ui.post(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try { startActivityForResult(i, OPENTXT); } catch (Exception e) { toast("Impossibile aprire il file"); }
            });
        }

        @JavascriptInterface
        public void remove(String url) {
            try {
                int k = url.indexOf("/f/");
                if (k < 0) return;
                Uri u = uriOf(url.substring(k + 3));
                if (!"file".equals(u.getScheme()) || u.getPath() == null) return;
                File f = new File(u.getPath());
                if (f.getCanonicalPath().startsWith(getFilesDir().getCanonicalPath())) f.delete();
            } catch (Exception ignored) { }
        }
    }
}
