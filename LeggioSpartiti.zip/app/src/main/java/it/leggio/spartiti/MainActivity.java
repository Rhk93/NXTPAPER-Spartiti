package it.leggio.spartiti;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String HOME = "https://appassets.androidplatform.net/assets/index.html";
    private static final int PICK = 1;
    private FrameLayout root;
    private WebView web, browser;
    private LinearLayout browserBox;
    private TextView browserTitle;
    private ValueCallback<Uri[]> fileCb;
    private boolean ready = false;
    private final List<String> pending = new ArrayList<>();
    private final ExecutorService ex = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        root = new FrameLayout(this);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Bridge(), "Leggio");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("https://appassets.androidplatform.net/")) return false;
                if (u.startsWith("http")) openBrowser(u);
                return true;
            }
            @Override
            public void onPageFinished(WebView v, String url) {
                ready = true;
                for (String js : pending) web.evaluateJavascript(js, null);
                pending.clear();
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/pdf", "image/*"});
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(Intent.createChooser(i, "Scegli PDF o immagini"), PICK);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        web.loadUrl(HOME);
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        handleIntent(i);
    }

    private void handleIntent(Intent i) {
        if (i == null) return;
        Uri u = null;
        if (Intent.ACTION_VIEW.equals(i.getAction())) u = i.getData();
        else if (Intent.ACTION_SEND.equals(i.getAction())) u = i.getParcelableExtra(Intent.EXTRA_STREAM);
        if (u == null) return;
        final Uri uri = u;
        final String mime = getContentResolver().getType(uri);
        ex.execute(() -> {
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                deliver(readAll(in), nameOf(uri), mime == null ? "" : mime);
            } catch (Exception e) {
                toast("Impossibile aprire il file");
            }
        });
    }

    private String nameOf(Uri u) {
        try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int k = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (k >= 0) return c.getString(k);
            }
        } catch (Exception ignored) { }
        return "Spartito";
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != PICK || fileCb == null) return;
        Uri[] out = null;
        if (res == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int n = data.getClipData().getItemCount();
                out = new Uri[n];
                for (int k = 0; k < n; k++) out[k] = data.getClipData().getItemAt(k).getUri();
            } else if (data.getData() != null) {
                out = new Uri[]{data.getData()};
            }
        }
        fileCb.onReceiveValue(out);
        fileCb = null;
    }

    private void openBrowser(String url) {
        if (browserBox == null) {
            browserBox = new LinearLayout(this);
            browserBox.setOrientation(LinearLayout.VERTICAL);
            browserBox.setBackgroundColor(Color.WHITE);
            LinearLayout bar = new LinearLayout(this);
            bar.setGravity(Gravity.CENTER_VERTICAL);
            bar.setBackgroundColor(Color.rgb(242, 242, 247));
            bar.setPadding(12, 8, 12, 8);
            Button close = new Button(this);
            close.setText("Fine");
            close.setOnClickListener(v -> browserBox.setVisibility(View.GONE));
            Button back = new Button(this);
            back.setText("‹ Indietro");
            back.setOnClickListener(v -> { if (browser.canGoBack()) browser.goBack(); });
            browserTitle = new TextView(this);
            browserTitle.setSingleLine(true);
            browserTitle.setTextSize(15);
            browserTitle.setTextColor(Color.BLACK);
            browserTitle.setPadding(16, 0, 16, 0);
            bar.addView(back);
            bar.addView(browserTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            bar.addView(close);
            TextView hint = new TextView(this);
            hint.setText("Scarica un PDF: verrà importato da solo nella cartella scelta");
            hint.setTextSize(12);
            hint.setTextColor(Color.rgb(110, 110, 115));
            hint.setPadding(24, 4, 24, 8);
            hint.setBackgroundColor(Color.rgb(242, 242, 247));
            browser = new WebView(this);
            WebSettings s = browser.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setBuiltInZoomControls(true);
            s.setDisplayZoomControls(false);
            s.setUseWideViewPort(true);
            s.setLoadWithOverviewMode(true);
            CookieManager.getInstance().setAcceptThirdPartyCookies(browser, true);
            browser.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                    String u = r.getUrl().toString();
                    if (!u.startsWith("http")) return true;
                    if (u.toLowerCase().matches(".*\\.pdf([?#].*)?$")) {
                        fetch(u, s.getUserAgentString(), null, null);
                        return true;
                    }
                    return false;
                }
                @Override
                public void onPageFinished(WebView v, String u) {
                    browserTitle.setText(v.getTitle());
                }
            });
            browser.setDownloadListener((u, ua, cd, mime, len) -> fetch(u, ua, cd, mime));
            browserBox.addView(bar, new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
            browserBox.addView(hint, new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
            browserBox.addView(browser, new LinearLayout.LayoutParams(-1, 0, 1));
            root.addView(browserBox, new FrameLayout.LayoutParams(-1, -1));
        }
        browserBox.setVisibility(View.VISIBLE);
        browser.loadUrl(url);
    }

    private void fetch(final String url, final String ua, final String cd, final String mime0) {
        if (url.startsWith("blob:") || url.startsWith("data:")) { toast("Questo download non è supportato"); return; }
        toast("Download in corso…");
        final String agent = ua != null ? ua : WebSettings.getDefaultUserAgent(this);
        ex.execute(() -> {
            HttpURLConnection c = null;
            try {
                String u = url;
                for (int k = 0; k < 8; k++) {
                    c = (HttpURLConnection) new URL(u).openConnection();
                    c.setInstanceFollowRedirects(false);
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(90000);
                    c.setRequestProperty("User-Agent", agent);
                    String ck = CookieManager.getInstance().getCookie(u);
                    if (ck != null) c.setRequestProperty("Cookie", ck);
                    int code = c.getResponseCode();
                    if (code >= 300 && code < 400 && c.getHeaderField("Location") != null) {
                        u = new URL(new URL(u), c.getHeaderField("Location")).toString();
                        c.disconnect();
                        continue;
                    }
                    break;
                }
                if (c.getResponseCode() >= 400) throw new IOException("HTTP " + c.getResponseCode());
                String mime = c.getContentType() != null ? c.getContentType() : (mime0 != null ? mime0 : "");
                String disp = c.getHeaderField("Content-Disposition") != null ? c.getHeaderField("Content-Disposition") : cd;
                String name = URLUtil.guessFileName(u, disp, mime);
                byte[] data;
                try (InputStream in = c.getInputStream()) { data = readAll(in); }
                if (mime.contains("text/html")) { toast("Il link non porta a un PDF: aprilo e scarica il file"); ui.post(() -> openBrowser(url)); return; }
                deliver(data, name, mime);
                toast("Spartito importato: " + name);
            } catch (Exception e) {
                toast("Download non riuscito");
            } finally {
                if (c != null) c.disconnect();
            }
        });
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        return out.toByteArray();
    }

    private void deliver(byte[] data, String name, String mime) {
        final String js = "leggioImport('" + Base64.encodeToString(data, Base64.NO_WRAP) + "',"
                + JSONObject.quote(name) + "," + JSONObject.quote(mime) + ")";
        ui.post(() -> {
            if (ready) web.evaluateJavascript(js, null);
            else pending.add(js);
        });
    }

    private void toast(final String t) {
        ui.post(() -> Toast.makeText(this, t, Toast.LENGTH_SHORT).show());
    }

    @Override
    public void onBackPressed() {
        if (browserBox != null && browserBox.getVisibility() == View.VISIBLE) {
            if (browser.canGoBack()) browser.goBack();
            else browserBox.setVisibility(View.GONE);
            return;
        }
        web.evaluateJavascript("window.leggioBack?leggioBack():false", v -> {
            if (!"true".equals(v)) finish();
        });
    }

    private class Bridge {
        @JavascriptInterface
        public void download(String url) { ui.post(() -> fetch(url, null, null, null)); }

        @JavascriptInterface
        public void browse(String url) { ui.post(() -> openBrowser(url)); }
    }
}
